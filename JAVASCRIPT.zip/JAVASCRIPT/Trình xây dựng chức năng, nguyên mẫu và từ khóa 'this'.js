//Bài giảng 48: Trình xây dựng chức năng, nguyên mẫu và từ khóa 'this'
function test ( ) {
    console.log(this);
    this.myName = "Yaakov";
}
test();
console.log(window.myName);

//Function constructors
function Circle (argument) {
    this.radius = radius;
    // this.getArea = function () {
    //     return Math.PI * Math.pow(this.radius, 2);
    // };  
}
Circle.prototype.getArea =
    function () {
        return Math.PI * Math.pow(this.radius, 2);
    }

var myCircle = new Circle(10);
console.log(myCircle.getArea());

var muOtherCircle = new Circle(20);
console.log(myOtherCircle);


//Bài giảng 49: Đối tượng văn học và từ khóa 'này'

// Object literals and "this"
var literalCircle = {
    redius: 10,
    getArea: function ( ) {
        console.log(this);
        var increaseRadius = function () {
            this.radius = 20;
        }
        increaseRadius();
        console.log(this.radius);
        return Math>PI * Math.pow(this.radius, 2);
    }
};

console.log(literalCircle.getArea());