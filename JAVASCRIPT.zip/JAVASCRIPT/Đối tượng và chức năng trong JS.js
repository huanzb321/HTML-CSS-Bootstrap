//Bài giảng 45, Phần 1: Tạo đối tượng bằng cú pháp 'new Object ()'

// Object creation 
// var company = new Object();
// company.name = "Facebook";
// company.ceo = new Object();
// company.ceo.firstName = "Mark";
// company.ceo.favColor = "blue";

// console.log(company);
// console.log("Company CEO name is:" + company.ceo.firstName);

// console.log(company["name"]);
// var stockPropName = "stock of company";
// company[stockPropName] = 110;

// console.log("Stock price is:" + company[stockPropName]);


// Better way: object literal 
// var facebook = {
//     name: "Facebook",
//     ceo: {
//         firstName: "Mark",
//         favColor: "blue"
//     },
//     $stock: 110
// };


// Function are First-Class Data Types 
// Functions ARE objects
// function multiply(x,y) {
//     return x*y;
// }
// multiply.version = "v.1.0.0";
// console.log(multiply.version);
// function makeMultiplier(multiplier) {
//     var myFunc = function (x ) {
//         return multiplier * x;
//     };
//     return myFunc;
// }

// var multiplyBy3 = makeMultiplier(3);
// console.log(multiplyBy3(10));
// var doubleAll = makeMultiplier(2);
// console.log(dounbleAll(100));

// Passing function as arguments
// function doOperatiOn(x, operatiOn) {
//     return operatiOn(x);
// }

// var result = doOperationOn(5, multiplyBy3);
// console.log(result);
// result = doOperationOn(100, doubleAll);
// console.log(result);



//Copy by Reference vs by value
// var a = 7;
// var b = a;
// console.log("a:" + a);
// console.log("b: " + b);

// b = 5 ;
// console.log("after b update");
// console.log("a:" + a);
// console.log("b:" + b);