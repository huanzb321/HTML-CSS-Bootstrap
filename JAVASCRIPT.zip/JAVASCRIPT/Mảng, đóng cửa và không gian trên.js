// Bài giảng 51: Đóng cửa
function makeMultiper (multiper) {
    return {
        function (x) {
            return multiper * x;
        }
    };
}

var doubleAll = makeMultiper(2);
console.log(doubleAll(10));

