//Lecture 43, Part 1: Common Language Constructs


// *** Nối chuỗi
// var string = "Hello";
// string += "World";
// console.log(string + "!");


// *** Toán tử toán học thông thường :, -, *, /
// console.log((5+4) / 3);
// console.log(undefined / 5);

// *** bình đẳng 
// var x = 4, y = 4;
// if (x == y) {
//     console.log("x=4 is qual to y=4");
// }

// x="4";
// if (x==y) {
//     console.log("x='4' is qual to y=4")
// }

// *** bình đẳng nghiêm ngặt
// if (x === y) {
//     console.log("Strict: x='4' is equal to y=4");
// }
// else {
//     console.log("Strict: x='4' is Not equal to y=4")
// }



//Lecture 43, Part 2: Common Language Constructs


//*** IF statement (all false) 
// if ( false || null || undefined || "" || 0 || NAN) {
//     console.log("This line won't ever execute");
// }
// else {
//     console.log("All false");
// }

// //*** IF statement (all true) 
// if (true && "hello" && 1 && -1 && "false" ) {
//     console.log("All true");
// }


//Lecture 43, Part 3: Common Language Constructs

// For loop
// for (var i = 0; i < 10; i++) {
//     sum = sum + i;
// }
// console.log("sum of 0 through is: " + sum);






